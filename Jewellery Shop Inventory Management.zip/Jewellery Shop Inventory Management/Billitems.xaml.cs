﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GDRNSDemo2
{
    /// <summary>
    /// Interaction logic for Billitems.xaml
    /// </summary>
    public partial class Billitems : Window
    {
        List<string> ItemType = new List<string> { "S", "G" };
        List<string> ItemDesc = new List<string>();
        
        public Billitems()
        {
            InitializeComponent();
            BilledItems = new ObservableCollection<ItemDetails>();

            ItemsViewModel IVM = new ItemsViewModel();
            
            foreach (ItemDetails i in IVM.Items)
            {
                ItemDesc.Add(i.ItemName);
            }

            ItemsDataGrid.ItemsSource = BilledItems;
            ItemDesccombobox.ItemsSource = ItemDesc;
            ItemTypeCombobox.ItemsSource = ItemType;
        }

        private void ItemsAdded(object sender, RoutedEventArgs e)
        {
            if(BilledItems.Count() == 0)
            {
                MessageBox.Show("No items were selected.", "Input Error");
            }
            
            else
            {
                foreach (ItemDetails i in BilledItems)
                {

                    if (i.ItemName.Length > 0 && i.Labour > 0 && i.Rate > 0 && i.Tinch.Length > 0 && i.Pcs > 0 && i.Type.Length > 0)
                        i.Amount = (i.Weight * i.Rate) + (i.Labour * i.Pcs);
                    else
                        MessageBox.Show("All fields must be filled.", "Input Error");
                    
                }

                

                BillGenerate billwin = new BillGenerate(BilledItems);
                billwin.Show();
                Close();
            }
        }



        public ObservableCollection<ItemDetails> BilledItems
        {
            get { return (ObservableCollection<ItemDetails>)GetValue(BilledItemsProperty); }
            set { SetValue(BilledItemsProperty, value); }
        }

        // Using a DependencyProperty as the backing store for BilledItems.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty BilledItemsProperty =
            DependencyProperty.Register("BilledItems", typeof(ObservableCollection<ItemDetails>), typeof(MainWindow), new PropertyMetadata(null));


    }
}
