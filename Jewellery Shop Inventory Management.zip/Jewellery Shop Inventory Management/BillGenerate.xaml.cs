﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GDRNSDemo2
{
    /// <summary>
    /// Interaction logic for BillGenerate.xaml
    /// </summary>

    public partial class BillGenerate : Window
    {
        
        float TotAmtC = 0;
        float TotWtC = 0;
        ObservableCollection<ItemDetails> BilledItems = new ObservableCollection<ItemDetails>();
        public BillGenerate()
        {
            InitializeComponent();
        }
        public BillGenerate(ObservableCollection<ItemDetails> BilledItemsCollection)
        {
            InitializeComponent();
            BilledItems = BilledItemsCollection;
            ItemsDataGrid.ItemsSource = BilledItems;

            
            TotItem.Text = BilledItems.Count.ToString();
            foreach (ItemDetails i in BilledItems)
            {
                TotAmtC = TotAmtC + i.Amount;
                TotWtC = TotWtC + i.Weight;
            }
            TotWt.Text = TotWtC.ToString() + "g";
            TotAmt.Text = "Rs " + TotAmtC.ToString();
            
        }

        private void PrintingBill(object sender, RoutedEventArgs e)
        {
            ItemsViewModel IVM = new ItemsViewModel();
            ItemDetails tempItem = new ItemDetails();
            int index = 0;

            foreach(ItemDetails i in BilledItems)
            {
                index = 0; 
                while(index < IVM.Items.Count)
                {
                    if(i.ItemName == IVM.Items[index].ItemName)
                    {
                        tempItem = i;
                        tempItem.Pcs = IVM.Items[index].Pcs - i.Pcs;
                        tempItem.Total = IVM.Items[index].Total - i.Weight;
                        //tempItem.Weight = IVM.Items[index].Weight;
                        tempItem.Amount = IVM.Items[index].Amount - i.Amount;

                        

                        IVM.UpdateItemInRepo(tempItem);
                    }
                    index++;
                }
            }

            PrintDialog printDialog = new PrintDialog();
            if(printDialog.ShowDialog() == true)
            {
                printDialog.PrintVisual(grid, "My First Bill");
            }
            Close();
        }
    }
}
