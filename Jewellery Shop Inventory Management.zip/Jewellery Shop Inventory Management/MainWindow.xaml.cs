﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Collections.ObjectModel;

namespace GDRNSDemo2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //--------------------------------------------------------------------------------------------------------------------
        //********************************** Initial State of Window *********************************************************
        //--------------------------------------------------------------------------------------------------------------------

        int TotSItemC = 0;
        int TotGItemC = 0;
        float TotWtC = 0;
        public MainWindow()
        {

            InitializeComponent();

            ItemsViewModel IVM = new ItemsViewModel();
            ItemsCollection = new ObservableCollection<ItemDetails>(IVM.ItemsRepository.itemsRepository);
            ItemsDataGrid.ItemsSource = ItemsCollection;

            TotItem.Text = IVM.Items.Count.ToString();
            foreach(ItemDetails i in IVM.Items)
            {
                if (i.Type == "S")
                    TotSItemC++;
                else
                    TotGItemC++;

                TotWtC = TotWtC + i.Total;
            }
            TotWt.Text = TotWtC.ToString() + "g";
            TotSItem.Text = TotSItemC.ToString();
            TotGItem.Text = TotGItemC.ToString();

            var cvs = CollectionViewSource.GetDefaultView(ItemsCollection);
            if(cvs != null && cvs.CanSort)
            {
                cvs.SortDescriptions.Clear();
                cvs.SortDescriptions.Add(new SortDescription("ItemName", ListSortDirection.Ascending));
            }

        }

        //--------------------------------------------------------------------------------------------------------------------

        //--------------------------------------------------------------------------------------------------------------------
        //************************************ Objects and Collections Used **************************************************
        //--------------------------------------------------------------------------------------------------------------------

        public ObservableCollection<ItemDetails> ItemsCollection
        {
            get { return (ObservableCollection<ItemDetails>)GetValue(ItemsCollectionProperty); }
            set { SetValue(ItemsCollectionProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ItemsCollection.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ItemsCollectionProperty =
            DependencyProperty.Register("ItemsCollection", typeof(ObservableCollection<ItemDetails>), typeof(MainWindow), new PropertyMetadata(null));




        public ItemDetails Items
        {
            get { return (ItemDetails)GetValue(ItemsProperty); }
            set { SetValue(ItemsProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Items.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ItemsProperty =
            DependencyProperty.Register("Items", typeof(ItemDetails), typeof(MainWindow), new PropertyMetadata(null));


        //-----------------------------------------------------------------------------------------------------------------------

        //-----------------------------------------------------------------------------------------------------------------------
        //************************************** BUTTONS AND THEIR FUNCTIONS ****************************************************
        //-----------------------------------------------------------------------------------------------------------------------

        private void AddNewItemClick(object sender, RoutedEventArgs e)
        {
            var win = new AddNewItem();
            win.ShowDialog();
            ItemsViewModel IVM = new ItemsViewModel();
            ItemsCollection = new ObservableCollection<ItemDetails>(IVM.ItemsRepository.itemsRepository);
            ItemsDataGrid.ItemsSource = ItemsCollection;

            TotSItemC = 0;
            TotGItemC = 0;
            TotWtC = 0;
            TotItem.Text = IVM.Items.Count.ToString();
            foreach (ItemDetails i in IVM.Items)
            {
                if (i.Type == "S")
                    TotSItemC++;
                else
                    TotGItemC++;

                TotWtC = TotWtC + i.Total;
            }
            TotWt.Text = TotWtC.ToString() + "g";
            TotSItem.Text = TotSItemC.ToString();
            TotGItem.Text = TotGItemC.ToString();
        }

        private void EditItemClick(object sender, RoutedEventArgs e)
        {
            if ((ItemDetails)ItemsDataGrid.SelectedItem == null)
            {
                MessageBox.Show("Error: No items were selected.", "Updation Error");
                return;
            }
            var Editwin = new EditItem((ItemDetails)ItemsDataGrid.SelectedItem);
            Editwin.ShowDialog();
            ItemsViewModel IVM = new ItemsViewModel();
            ItemsCollection = new ObservableCollection<ItemDetails>(IVM.ItemsRepository.itemsRepository);
            ItemsDataGrid.ItemsSource = ItemsCollection;

            TotSItemC = 0;
            TotGItemC = 0;
            TotWtC = 0;
            TotItem.Text = IVM.Items.Count.ToString();
            foreach (ItemDetails i in IVM.Items)
            {
                if (i.Type == "S")
                    TotSItemC++;
                else
                    TotGItemC++;

                TotWtC = TotWtC + i.Total;
            }
            TotWt.Text = TotWtC.ToString() + "g";
            TotSItem.Text = TotSItemC.ToString();
            TotGItem.Text = TotGItemC.ToString();
        }

        private void DeleteItemClick(object sender, RoutedEventArgs e)
        {
            if ((ItemDetails)ItemsDataGrid.SelectedItem == null)
            {
                MessageBox.Show("Error: No items were selected.", "Deletion Error");
                return;
            }

            
            ItemDetails it = (ItemDetails)ItemsDataGrid.SelectedItem;
            ItemsViewModel IVM = new ItemsViewModel();
            MessageBoxResult res = MessageBox.Show("Are you sure you want to delete this item?", "Delete Item", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if(res == MessageBoxResult.Yes)
            {
                IVM.DeleteItemFromRepo(it.ItemName);
                ItemsCollection = new ObservableCollection<ItemDetails>(IVM.ItemsRepository.itemsRepository);
                ItemsCollection.Remove((ItemDetails)ItemsDataGrid.SelectedItem);
                ItemsDataGrid.ItemsSource = ItemsCollection;
            }
            

            TotSItemC = 0;
            TotGItemC = 0;
            TotWtC = 0;
            TotItem.Text = IVM.Items.Count.ToString();
            foreach (ItemDetails i in IVM.Items)
            {
                if (i.Type == "S")
                    TotSItemC++;
                else
                    TotGItemC++;

                TotWtC = TotWtC + i.Total;
            }
            TotWt.Text = TotWtC.ToString() + "g";
            TotSItem.Text = TotSItemC.ToString();
            TotGItem.Text = TotGItemC.ToString();
        }

        private void NewBillClick(object sender, RoutedEventArgs e)
        {
            var win = new Billitems();
            win.ShowDialog();
            ItemsViewModel IVM = new ItemsViewModel();
            ItemsCollection = new ObservableCollection<ItemDetails>(IVM.ItemsRepository.itemsRepository);
            ItemsDataGrid.ItemsSource = ItemsCollection;

            TotSItemC = 0;
            TotGItemC = 0;
            TotWtC = 0;
            TotItem.Text = IVM.Items.Count.ToString();
            foreach (ItemDetails i in IVM.Items)
            {
                if (i.Type == "S")
                    TotSItemC++;
                else
                    TotGItemC++;

                TotWtC = TotWtC + i.Total;
            }
            TotWt.Text = TotWtC.ToString() + "g";
            TotSItem.Text = TotSItemC.ToString();
            TotGItem.Text = TotGItemC.ToString();
        }

        //--------------------------------------------------------------------------------------------------------------------

        //--------------------------------------------------------------------------------------------------------------------
        //******************************************* CHECHBOXES AND THEIR FUNCTIONS *****************************************
        //--------------------------------------------------------------------------------------------------------------------
        private void SortByWeightChecked(object sender, RoutedEventArgs e)
        {
            var cvs = CollectionViewSource.GetDefaultView(ItemsCollection);
            if (cvs != null && cvs.CanSort)
            {
                cvs.SortDescriptions.Clear();
                if(SortByWeight.IsChecked == true)
                {
                    cvs.SortDescriptions.Add(new SortDescription("Total", ListSortDirection.Descending));
                }
                else
                {
                    cvs.SortDescriptions.Clear();
                    cvs.SortDescriptions.Add(new SortDescription("ItemName", ListSortDirection.Ascending));
                }
            }
        }
        private void SortByWeightUnchecked(object sender, RoutedEventArgs e)
        {
            var cvs = CollectionViewSource.GetDefaultView(ItemsCollection);
            if (cvs != null && cvs.CanSort)
            {
                cvs.SortDescriptions.Clear();
                if (SortByWeight.IsChecked == false)
                {
                    cvs.SortDescriptions.Clear();
                    cvs.SortDescriptions.Add(new SortDescription("ItemName", ListSortDirection.Ascending));
                }
            }
        }


        private void SortByPcsChecked(object sender, RoutedEventArgs e)
        {
            var cvs = CollectionViewSource.GetDefaultView(ItemsCollection);
            if (cvs != null && cvs.CanSort)
            {
                cvs.SortDescriptions.Clear();

                if(SortByPcs.IsChecked == true)
                {
                    cvs.SortDescriptions.Add(new SortDescription("Pcs", ListSortDirection.Descending));
                }
                else
                {
                    cvs.SortDescriptions.Clear();
                    cvs.SortDescriptions.Add(new SortDescription("ItemName", ListSortDirection.Ascending));
                }
            }
        }
        private void SortByPcsUnchecked(object sender, RoutedEventArgs e)
        {
            var cvs = CollectionViewSource.GetDefaultView(ItemsCollection);
            if (cvs != null && cvs.CanSort)
            {
                cvs.SortDescriptions.Clear();

                if (SortByPcs.IsChecked == false)
                {
                    cvs.SortDescriptions.Clear();
                    cvs.SortDescriptions.Add(new SortDescription("ItemName", ListSortDirection.Ascending));
                }
            }
        }


        private void SortByTypeChecked(object sender, RoutedEventArgs e)
        {
            var cvs = CollectionViewSource.GetDefaultView(ItemsCollection);
            if(cvs != null && cvs.CanGroup)
            {
                cvs.GroupDescriptions.Clear();
                if(SortByType.IsChecked == true)
                {
                    cvs.GroupDescriptions.Add(new PropertyGroupDescription("Type"));
                }
                else
                {
                    cvs.GroupDescriptions.Clear();
                }
            }
        }
        private void SortByTypeUnchecked(object sender, RoutedEventArgs e)
        {
            var cvs = CollectionViewSource.GetDefaultView(ItemsCollection);
            if (cvs != null && cvs.CanGroup)
            {
                cvs.GroupDescriptions.Clear();
                if (SortByType.IsChecked == false)
                {
                    cvs.GroupDescriptions.Clear();
                }
            }
        }

        //--------------------------------------------------------------------------------------------------------------------
    }
}
