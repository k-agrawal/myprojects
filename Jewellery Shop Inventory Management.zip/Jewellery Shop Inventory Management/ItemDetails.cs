﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace GDRNSDemo2
{
    public class ItemDetails
    {

        
        public string ItemName { get; set; }
        public string Tinch { get; set; }
        public string Type { get; set; }
        public float Weight { get; set; }
        public float Labour { get; set; }
        public float Rate { get; set; }
        public int Pcs { get; set; }
        public float Total { get; set; }
        public float Amount { get; set; }

    }
}
