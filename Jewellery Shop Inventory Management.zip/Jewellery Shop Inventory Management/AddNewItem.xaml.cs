﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GDRNSDemo2
{
    /// <summary>
    /// Interaction logic for AddNewItem.xaml
    /// </summary>
    public partial class AddNewItem : Window
    {
        public AddNewItem()
        {
            InitializeComponent();
        }

        private void AddingItem(object sender, RoutedEventArgs e)
        {



            if(ItemTextBox.Text.Length > 0 && PcsTextBox.Text.Length > 0 && WeightTextBox.Text.Length > 0 && TinchTextBox.Text.Length > 0 && LabourTextBox.Text.Length > 0)
            {
                ItemDetails newItem = new ItemDetails();
                newItem.ItemName = ItemTextBox.Text;
                newItem.Tinch = TinchTextBox.Text;

                newItem.Pcs = Int32.Parse(PcsTextBox.Text);
                if (TypeSrdo.IsChecked == true)
                    newItem.Type = "S";
                else
                    newItem.Type = "G";

                newItem.Total = float.Parse(WeightTextBox.Text);

                newItem.Labour = float.Parse(LabourTextBox.Text);
                ((MainWindow)Application.Current.MainWindow).ItemsCollection.Add(newItem);
                ItemsViewModel IVM = new ItemsViewModel();
                IVM.AddItemToRepo(newItem);
                Close();
            }
            else
            {
                MessageBox.Show("All the fields must be entered.","Input Error");
                
            }
            
        }

        public string a_ItemName { get; set; }
        public float a_Rate { get; set; }
        public float a_Labour { get; set; }
        public float a_Amount { get; set; }
        public string a_Tinch { get; set; }
        public string a_Type { get; set; }
        public float a_Weight { get; set; }
        public int a_Pcs { get; set; }
        public float a_Total { get; set; }

        private void OnCancelling(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }

        
    }

