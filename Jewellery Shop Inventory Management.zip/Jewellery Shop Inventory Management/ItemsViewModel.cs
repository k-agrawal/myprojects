﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace GDRNSDemo2
{
    class ItemsViewModel 
    {
        public ObservableCollection<ItemDetails> Items { get; set; }
        public ItemsRepository ItemsRepository { get; set; }

        public ItemsViewModel()
        {
            ItemsRepository = new ItemsRepository();
            Items = new ObservableCollection<ItemDetails>(ItemsRepository.itemsRepository);
            Items.CollectionChanged += Items_CollectionChanged;
        }
         
        //Function: Search for query string in the collection

        public List<ItemDetails> searchRepo(string searchQuery)
        {
            if (searchQuery == "*" || searchQuery == " ")
                throw new Exception("Warning: Symbols such as * or whiteSpaces are not allowed.");
            

            List<ItemDetails> ItemsList = (from tempItem in Items where tempItem.ItemName.Contains(searchQuery) select tempItem).ToList();

            return ItemsList;
        }

       

        //Function: Adds a new Item in the collection and Database
        public void AddItemToRepo(ItemDetails item)
        {
            if (item == null)
                throw new ArgumentNullException("Error: The argument is NULL.");
            
            Items.Add(item);
        }

        //Function: Deletes an item from collection and Database
        public void DeleteItemFromRepo(string Iname)
        {
            if (Iname == " ")
            {
                MessageBox.Show("Error:No item was selected.", "Deletion Error");
                return;
            }
            
            int index = 0;
            while (index < Items.Count)
            {
                if (Items[index].ItemName == Iname)
                {
                    Items.RemoveAt(index);
                }
                index++;
            }
        }

        //Function: Updates the Item in collection and Database
        public void UpdateItemInRepo(ItemDetails i)
        {
            if (i.ItemName == " ")
            {
                MessageBox.Show("Error: No items were selected.","Update Error");
                return;
            }

            int index = 0;

            while(index < Items.Count)
            {
                if(Items[index].ItemName == i.ItemName)
                {
                    Items[index] = i;
                }
              index++;
            }
        }

        //EventHandler: Handles the CollectionChanged event of ObservableCollection
        //Updates the dtatabase if any change is made to the Items Collection

        private void Items_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            if(e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Add)
            {
                int newIndex = e.NewStartingIndex;
                
                ItemsRepository.addNewRecord(Items[newIndex]);
            }
            else if (e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Remove)
            {
                List<ItemDetails> tempListOfRemovedItems = e.OldItems.OfType<ItemDetails>().ToList();
                ItemsRepository.DelRecord(tempListOfRemovedItems[0].ItemName);
            }
            else if (e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Replace)
            {
                List<ItemDetails> tempListOfItems = e.NewItems.OfType<ItemDetails>().ToList();
                ItemsRepository.updateRecord(tempListOfItems[0]);
            }
        }
        
    }
}
