﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Windows;

namespace GDRNSDemo2
{
    class ItemsRepository
    {
        public List<ItemDetails> itemsRepository { get; set; }

        public ItemsRepository()
        {
            itemsRepository = GetItemRepo();
        }

        public List<ItemDetails> GetItemRepo()
        {
            List<ItemDetails> listOfItems = new List<ItemDetails>();

            using (SqlConnection con = new SqlConnection(Properties.Settings.Default.conString))
            {
                if(con == null)
                {
                    throw new Exception("Connection String is NULL.");
                }

                SqlCommand query = new SqlCommand("SELECT * from Items", con);
                con.Open();
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query);
                DataTable dataTable = new DataTable();
                sqlDataAdapter.Fill(dataTable);

                foreach (DataRow row in dataTable.Rows)
                {
                    ItemDetails id = new ItemDetails();
                    
                    id.ItemName = (string)row["ItemName"];
                    id.Labour = float.Parse(row["Labour"].ToString());
                    id.Pcs = (int)row["Pcs"];
                    id.Rate = float.Parse(row["Rate"].ToString());
                    id.Tinch = (string)row["Tinch"];
                    id.Type = (string)row["Type"];
                    id.Weight = float.Parse(row["Weight"].ToString());
                    id.Total = float.Parse(row["TotalWt"].ToString());
                    id.Amount = float.Parse(row["Amount"].ToString());

                    listOfItems.Add(id);
                }
                return listOfItems;
            }
        }

        public List<ItemDetails> GetItemRepoSearch(string searchQuery)
        {
            List<ItemDetails> listOfItems = new List<ItemDetails>();

            using (SqlConnection con = new SqlConnection(Properties.Settings.Default.conString))
            {
                if (con == null)
                {
                    throw new Exception("Connection String is NULL.");
                }

                SqlCommand query = new SqlCommand("returnRecord", con);
                con.Open();

                query.CommandType = CommandType.StoredProcedure;
                SqlParameter param = new SqlParameter("TitlePhrase", SqlDbType.VarChar);
                param.Value = searchQuery;
                query.Parameters.Add(param);

                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query);
                DataTable dataTable = new DataTable();
                sqlDataAdapter.Fill(dataTable);

                foreach (DataRow row in dataTable.Rows)
                {
                    ItemDetails id = new ItemDetails();
                    
                    id.ItemName = (string)row["ItemName"];
                    id.Labour = (float)row["Labour"];
                    id.Pcs = (int)row["Pcs"];
                    id.Rate = (float)row["Rate"];
                    id.Tinch = (string)row["Tinch"];
                    id.Type = (string)row["Type"];
                    id.Weight = (float)row["Weight"];
                    id.Total = (float)row["TotalWt"];
                    id.Amount = (float)row["Amount"];

                    listOfItems.Add(id);
                }
                return listOfItems;
            }
        }

        public void addNewRecord(ItemDetails item)
        {
            List<ItemDetails> listOfItems = new List<ItemDetails>();

            using (SqlConnection con = new SqlConnection(Properties.Settings.Default.conString))
            {
                if (con == null)
                {
                    throw new Exception("Connection String is NULL.");
                }
                else if (item == null)
                {
                    throw new Exception("Error!No value passed.");
                }

                
                SqlCommand query = new SqlCommand("addRecord", con);
                con.Open();

                query.CommandType = CommandType.StoredProcedure;
                
                SqlParameter param1 = new SqlParameter("Iname", SqlDbType.VarChar);
                SqlParameter param2 = new SqlParameter("Type", SqlDbType.VarChar);
                SqlParameter param3 = new SqlParameter("Weight", SqlDbType.Float);
                SqlParameter param4 = new SqlParameter("Tinch", SqlDbType.VarChar);
                SqlParameter param5 = new SqlParameter("Pcs", SqlDbType.Int);
                SqlParameter param6 = new SqlParameter("Labour", SqlDbType.Float);
                SqlParameter param7 = new SqlParameter("Rate", SqlDbType.Float);
                SqlParameter param8 = new SqlParameter("TotalWt", SqlDbType.Float);
                SqlParameter param9 = new SqlParameter("Amount", SqlDbType.Float);

                
                param1.Value = item.ItemName;
                param2.Value = item.Type;
                param3.Value = item.Weight;
                param4.Value = item.Tinch;
                param5.Value = item.Pcs;
                param6.Value = item.Labour;
                param7.Value = item.Rate;
                param8.Value = item.Total;
                param9.Value = item.Amount;

                
                query.Parameters.Add(param1);
                query.Parameters.Add(param2);
                query.Parameters.Add(param3);
                query.Parameters.Add(param4);
                query.Parameters.Add(param5);
                query.Parameters.Add(param6);
                query.Parameters.Add(param7);
                query.Parameters.Add(param8);
                query.Parameters.Add(param9);
                
                query.ExecuteNonQuery();
            }
        }

        public void DelRecord(string Iname)
        {
            using (SqlConnection con = new SqlConnection(Properties.Settings.Default.conString))
            {
                if (con == null)
                {
                    throw new Exception("Connection String is NULL.");
                }
                SqlCommand query = new SqlCommand("deleteRecord", con);
                con.Open();
                query.CommandType = CommandType.StoredProcedure;
                SqlParameter param = new SqlParameter("Iname", SqlDbType.VarChar);
                param.Value = Iname;
                query.Parameters.Add(param);

                query.ExecuteNonQuery();
            }
        }

        public void updateRecord(ItemDetails item)
        {
            List<ItemDetails> listOfItems = new List<ItemDetails>();

            using (SqlConnection con = new SqlConnection(Properties.Settings.Default.conString))
            {
                if (con == null)
                {
                    throw new Exception("Connection String is NULL.");
                }
                
                SqlCommand query = new SqlCommand("updateRecord", con);
                con.Open();

                query.CommandType = CommandType.StoredProcedure;
                SqlParameter param1 = new SqlParameter("Iname", SqlDbType.VarChar);
                SqlParameter param2 = new SqlParameter("Type", SqlDbType.VarChar);
                SqlParameter param3 = new SqlParameter("Weight", SqlDbType.Float);
                SqlParameter param4 = new SqlParameter("Tinch", SqlDbType.VarChar);
                SqlParameter param5 = new SqlParameter("Pcs", SqlDbType.Int);
                SqlParameter param6 = new SqlParameter("Labour", SqlDbType.Float);
                SqlParameter param7 = new SqlParameter("Rate", SqlDbType.Float);
                SqlParameter param8 = new SqlParameter("TotalWt", SqlDbType.Float);
                SqlParameter param9 = new SqlParameter("Amount", SqlDbType.Float);

                param1.Value = item.ItemName;
                param2.Value = item.Type;
                param3.Value = item.Weight;
                param4.Value = item.Tinch;
                param5.Value = item.Pcs;
                param6.Value = item.Labour;
                param7.Value = item.Rate;
                param8.Value = item.Total;
                param9.Value = item.Amount;

                query.Parameters.Add(param1);
                query.Parameters.Add(param2);
                query.Parameters.Add(param3);
                query.Parameters.Add(param4);
                query.Parameters.Add(param5);
                query.Parameters.Add(param6);
                query.Parameters.Add(param7);
                query.Parameters.Add(param8);
                query.Parameters.Add(param9);

                query.ExecuteNonQuery();
            }
        }


    }
}
