﻿

USE [C:\USERS\KANIS\SOURCE\REPOS\GDRNSDEMO2\ITEMSDATABASE.MDF]

GO


CREATE TABLE [dbo].[Items] (
 [ItemName] VARCHAR(40),
 [Type] VARCHAR(2) NOT NULL,
 [Weight] FLOAT NOT NULL,
 [Tinch] VARCHAR(5) NOT NULL,
 [Pcs] INT NOT NULL,
 [Labour] FLOAT NOT NULL,
 [Rate] FLOAT NOT NULL,
 [TotalWt] FLOAT NOT NULL,
 [Amount] FLOAT NOT NULL,
 PRIMARY KEY CLUSTERED ([ItemName] ASC));
 

 GO

 CREATE PROCEDURE [dbo].[addRecord]
 @IName VARCHAR(40),
 @Type VARCHAR(2),
 @Weight FLOAT,
 @Tinch VARCHAR(5),
 @Pcs INT,
 @Labour FLOAT,
 @Rate FLOAT,
 @TotalWt FLOAT,
 @Amount FLOAT
AS
	INSERT INTO Items (ItemName,Type,Weight,Tinch,Pcs,Labour,Rate,TotalWt,Amount) VALUES (@Iname,@Type,@Weight,@Tinch,@Pcs,@Labour,@Rate,@TotalWt,@Amount);

GO

CREATE PROCEDURE [dbo].[deleteRecord]
@IName VARCHAR(40)
AS
	DELETE Items WHERE ItemName = @IName;

GO

CREATE PROCEDURE [dbo].[returnRecord]
@TitlePhrase VARCHAR(40)
AS
declare @param VARCHAR(40)
set @param = '%' + @TitlePhrase + '%'

SELECT * FROM Items WHERE ItemName LIKE @param;

GO

CREATE PROCEDURE [dbo].[updateRecord]
 @IName VARCHAR(40),
 @Type VARCHAR(2),
 @Weight FLOAT,
 @Tinch VARCHAR(5),
 @Pcs INT,
 @Labour FLOAT,
 @Rate FLOAT,
 @TotalWt FLOAT,
 @Amount FLOAT
AS
	UPDATE Items 
	SET ItemName=@Iname,
	Type=@Type,
	Weight=@Weight,
	Tinch=@Tinch,
	Pcs=@Pcs,
	Labour=@Labour,
	Rate=@Rate,
	TotalWt=@TotalWt,
	Amount=@Amount
	WHERE ItemName = @Iname;

GO