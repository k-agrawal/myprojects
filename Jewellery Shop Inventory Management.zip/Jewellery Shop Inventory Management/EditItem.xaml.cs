﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GDRNSDemo2
{
    /// <summary>
    /// Interaction logic for EditItem.xaml
    /// </summary>
    public partial class EditItem : Window
    {
        
        public EditItem()
        {
            InitializeComponent();
        }
        public EditItem(ItemDetails item)
        {
            InitializeComponent();

            DataContext = item;
            if (item.Type == "S")
                TypeSrdo.IsChecked = true;
            else
                TypeGrdo.IsChecked = true;

        }

        private void SavingItem(object sender, RoutedEventArgs e)
        {
            if (ItemTextBox.Text.Length > 0 && PcsTextBox.Text.Length > 0 && WeightTextBox.Text.Length > 0 && TinchTextBox.Text.Length > 0 && LabourTextBox.Text.Length > 0)
            {
                ItemDetails i = new ItemDetails();
                i.ItemName = ItemTextBox.Text;
                i.Tinch = TinchTextBox.Text;
                //i.Rate = float.Parse(RateTextBox.Text);
                i.Pcs = Int32.Parse(PcsTextBox.Text);
                i.Labour = float.Parse(LabourTextBox.Text);
                i.Total = float.Parse(WeightTextBox.Text);

                if (TypeSrdo.IsChecked == true)
                    i.Type = "S";
                else
                    i.Type = "G";

                //i.Total = i.Pcs * i.Weight;
                i.Amount = (i.Total * i.Rate) + (i.Labour * i.Pcs);



                ItemsViewModel IVM = new ItemsViewModel();
                IVM.UpdateItemInRepo(i);

                Close();
            }
            else
            {
                MessageBox.Show("All the fields must be entered","Input Error");
            }


            
        }

        private void OnCancelling(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
